package com.autosheet.model;

import org.springframework.data.annotation.Version;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Usuario")
public class Usuario {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_usuario;
	@Column(name = "nombre_usuario")
    private String nombre;
	@Column(name = "email")
    private String email;
	@Column(name = "contrasenya")
    private String contrasena;
	@Column(name = "total_fichas")
    private String total_fichas;
    
    @Enumerated(EnumType.STRING)
    private Rol rol;
    
    @Version
    private int version;

	public Usuario() {
		super();
	}

	public Usuario(Long id_usuario, String nombre, String email, String contrasena, String total_fichas, Rol rol,
			int version) {
		super();
		this.id_usuario = id_usuario;
		this.nombre = nombre;
		this.email = email;
		this.contrasena = contrasena;
		this.total_fichas = total_fichas;
		this.rol = rol;
		this.version = version;
	}

	public Long getId_usuario() {
		return id_usuario;
	}

	public void setId_usuario(Long id_usuario) {
		this.id_usuario = id_usuario;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContrasena() {
		return contrasena;
	}

	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}

	public String getTotal_fichas() {
		return total_fichas;
	}

	public void setTotal_fichas(String total_fichas) {
		this.total_fichas = total_fichas;
	}

	public Rol getRol() {
		return rol;
	}

	public void setRol(Rol rol) {
		this.rol = rol;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@Override
	public String toString() {
		return "Usuario [id_usuario=" + id_usuario + ", nombre=" + nombre + ", email=" + email + ", contrasena="
				+ contrasena + ", total_fichas=" + total_fichas + ", rol=" + rol + ", version=" + version + "]";
	}
}

package com.autosheet.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Sistema_fichas")
public class Sistema_fichas {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_sistema;
}

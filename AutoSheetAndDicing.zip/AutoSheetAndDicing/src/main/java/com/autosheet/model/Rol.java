package com.autosheet.model;

public enum Rol {
    admin, usuario
}

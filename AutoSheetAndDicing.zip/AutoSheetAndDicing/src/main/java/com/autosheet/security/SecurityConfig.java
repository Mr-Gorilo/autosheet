package com.autosheet.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.autosheet.model.Usuario;
import com.autosheet.repository.UsuarioRepository;


@EnableWebSecurity
@EnableMethodSecurity
@Configuration
public class SecurityConfig {
	
	public SecurityConfig() {
		super();
	}
	
	@Bean
	SecurityFilterChain filterChain(final HttpSecurity http) throws Exception {
        http
        	.csrf((csrf) -> csrf.disable()) //CSRF está habilitado por defecto y con esto se deshabilita
            .formLogin(formLogin -> formLogin
                    .loginPage("/login")
                    .failureUrl("/login?error=true"))
            .httpBasic(Customizer.withDefaults())
            .logout(logout -> logout
                    .logoutSuccessUrl("/login"))
            .authorizeHttpRequests(authorize -> authorize
                    .requestMatchers(
                    		new AntPathRequestMatcher("/api/**"),
                            new AntPathRequestMatcher("/"),
                            new AntPathRequestMatcher("/index"),
                            new AntPathRequestMatcher("/login"),
                            new AntPathRequestMatcher("/createUser"),
                            new AntPathRequestMatcher("/favicon.ico")).permitAll()
                    .requestMatchers(new AntPathRequestMatcher("/listaFichas/**")).hasAnyRole("admin", "usuario")
                    .requestMatchers(new AntPathRequestMatcher("/listaUsuarios/**")).hasAnyRole("admin", "usuario")
                    .requestMatchers(new AntPathRequestMatcher("/crearMascota/**")).hasAnyRole("admin", "usuario")
                    .requestMatchers(new AntPathRequestMatcher("/listaUsuarios/**")).hasRole("admin")
                    .requestMatchers(new AntPathRequestMatcher("/user/**")).hasRole("USUARIO")
                    .anyRequest().authenticated())
            .exceptionHandling(handling -> handling
                    .accessDeniedPage("/403"));
        return http.build();
    }
	
    @Bean
    public UserDetailsService userDetailsRepository(UsuarioRepository usuarioRepository) {
    	return nombre -> {
    		Usuario usuario = usuarioRepository.findByNombre(nombre);
    		if (usuario == null) {
    			throw new UsernameNotFoundException(nombre);
    		}
    		return User
    				.builder()
    				.username(usuario.getNombre())
    				.password("{noop}" + usuario.getContrasena())
    				.password(usuario.getEmail())
    				.roles(usuario.getRol().name())
    				.build();
    	};
    }
}

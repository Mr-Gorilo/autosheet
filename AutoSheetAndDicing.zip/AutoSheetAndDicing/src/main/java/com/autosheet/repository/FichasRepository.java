package com.autosheet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.autosheet.model.Ficha;

public interface FichasRepository extends JpaRepository<Ficha, Long> {

}

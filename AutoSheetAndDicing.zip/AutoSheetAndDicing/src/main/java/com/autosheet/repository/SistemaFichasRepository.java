package com.autosheet.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.autosheet.model.Sistema_fichas;


public interface SistemaFichasRepository extends JpaRepository<Sistema_fichas, Long> {

}

package com.autosheet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoSheetAndDicingApplicationTests {

	@Test
	void contextLoads() {
	}

}

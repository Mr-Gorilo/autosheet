DROP DATABASE IF EXISTS autoSheet;

CREATE DATABASE autoSheet;
USE autoSheet;

-- Table: Usuario
CREATE TABLE Usuario (
    id_usuario INT PRIMARY KEY,
    nombre_usuario VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    contrasenya VARCHAR(50) NOT NULL,
    total_fichas INT,
    rol ENUM('admin', 'usuario') NOT NULL
);

-- Table: Sistema_de_fichas
CREATE TABLE Sistema_fichas (
    id_sistema INT PRIMARY KEY,
    nombre_sistema VARCHAR(50) NOT NULL,
    descripcion VARCHAR(100),
    fichas_totales INT,
    sistema_juego VARCHAR(50)
);

-- Table: Ficha
CREATE TABLE Ficha (
    id_ficha INT PRIMARY KEY,
    id_sistema INT,
    id_usuario INT,
    FOREIGN KEY (id_sistema) REFERENCES Sistema_fichas(id_sistema) ON DELETE SET NULL,
    FOREIGN KEY (id_usuario) REFERENCES Usuario(id_usuario) ON DELETE SET NULL
);
